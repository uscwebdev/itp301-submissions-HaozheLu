import React from 'react';
import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import './index.css';
import Products from './Product.js';
const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <div id="header">
      <h1>Automobile Cart</h1>
    </div>
    <div id="main">
      <Products />
    </div>
    <div id="footer">
      <h3>Automobile Cart</h3>
    </div>
  </React.StrictMode>
);
