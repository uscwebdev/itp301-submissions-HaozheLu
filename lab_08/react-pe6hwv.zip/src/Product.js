import React from 'react';
import { useState } from 'react';
export default function Products() {
  const [subtotal, setSubtotal] = useState(0);

  function increaseSub(price) {
    price = parseInt(price);
    setSubtotal(subtotal + price);
  }
  function decreaseSub(price) {
    price = parseInt(price);
    setSubtotal(subtotal - price);
  }
  return (
    <div id="products">
      <div id="cars">
        <Product
          number="1"
          src="https://www.team-bhp.com/sites/default/files/styles/amp_high_res/public/20_audi_a4_render_2021_final.jpg"
          name="2024 Audi A4"
          price="41200"
          parentEventHandlerA={increaseSub}
          parentEventHandlerB={decreaseSub}
        />
        <Product
          number="2"
          src="https://cdn.carbuzz.com/gallery-images/1600/816000/900/816902.jpg"
          name="2023 Mercedes-Benz C300"
          price="46000"
          parentEventHandlerA={increaseSub}
          parentEventHandlerB={decreaseSub}
        />
        <Product
          number="3"
          src="https://www.leithbmw.com/assets/stock/colormatched_01/transparent/1280/cc_2024bms19_01_1280/cc_2024bms190011_01_1280_c4w.png?bg-color=FFFFFF&width=400%20400w"
          name="2024 BMW X5"
          price="65200"
          parentEventHandlerA={increaseSub}
          parentEventHandlerB={decreaseSub}
        />
        <Product
          number="4"
          src="https://vehicle-images.dealerinspire.com/d215-110009553/thumbnails/large/WP1BA2AY6RDA50881/d0e046cb1e6b20475ed3167ac9b008cc.jpg"
          name="2024 Porsche Cayenne Coupe"
          price="84300"
          parentEventHandlerA={increaseSub}
          parentEventHandlerB={decreaseSub}
        />
      </div>
      <div id="subtotal">
        <strong>Subtotal: ${subtotal}</strong>
      </div>
    </div>
  );
}

function Product(props) {
  // state variable to display the count
  const [counter, setCounter] = useState(0);
  // event handlers
  function handleMinusClick() {
    if (counter > 0) {
      setCounter(counter - 1);
      props.parentEventHandlerB(props.price);
    }
  }
  function handlePlusClick() {
    setCounter(counter + 1);
    props.parentEventHandlerA(props.price);
  }
  return (
    <div id={'car' + props.number} className="auto">
      <img className="img" src={props.src} alt={props.name} />
      <strong>{props.name}</strong>
      <strong>${props.price}</strong>
      {/* {add the buttons and the count} */}
      <div className="counterButtons">
        <button id="minusB" onClick={handleMinusClick}>
          -
        </button>
        <span>{counter}</span>
        <button id="plusB" onClick={handlePlusClick}>
          +
        </button>
      </div>
    </div>
  );
}
