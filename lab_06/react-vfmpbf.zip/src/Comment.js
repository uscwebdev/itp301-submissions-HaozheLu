import React from 'react';
export default function Comment(props) {
  return (
    <div id={'box' + props.userName} className="boxes">
      <img className="box-img" src={props.src} alt={props.alt} />
      <h3>{'User' + props.userName}</h3>
      <h3>{'Date: ' + props.date}</h3>
      <h3>Comment: </h3>
      <p>{props.content}</p>
    </div>
  );
}
