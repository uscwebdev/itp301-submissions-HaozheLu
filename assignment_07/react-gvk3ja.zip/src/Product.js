import React from 'react';
import { useState } from 'react';
export default function Product(props) {
  // state variable to display the count
  const [counter, setCounter] = useState(0);
  // event handlers
  function handleMinusClick() {
    if (counter > 0) {
      setCounter(counter - 1);
    }
  }
  function handlePlusClick() {
    setCounter(counter + 1);
  }
  return (
    <div id={'car' + props.number} className="auto">
      <img className="img" src={props.src} alt={props.name} />
      <strong>{props.name}</strong>
      <strong>{props.price}</strong>
      {/* {add the buttons and the count} */}
      <div className="counterButtons">
        <button id="minusB" onClick={handleMinusClick}>
          -
        </button>
        <span>{counter}</span>
        <button id="plusB" onClick={handlePlusClick}>
          +
        </button>
      </div>
    </div>
  );
}
