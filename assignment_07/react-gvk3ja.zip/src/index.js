import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import Product from './Product.js';
const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <div id="header">
      <h1>Automobile Cart</h1>
    </div>
    <div id="main">
      <div id="cars">
        <Product
          number="1"
          src="https://www.team-bhp.com/sites/default/files/styles/amp_high_res/public/20_audi_a4_render_2021_final.jpg"
          name="2024 Audi A4"
          price="$41200"
        />
        <Product
          number="2"
          src="https://cdn.carbuzz.com/gallery-images/1600/816000/900/816902.jpg"
          name="2023 Mercedes-Benz C300"
          price="$46000"
        />
        <Product
          number="3"
          src="https://www.leithbmw.com/assets/stock/colormatched_01/transparent/1280/cc_2024bms19_01_1280/cc_2024bms190011_01_1280_c4w.png?bg-color=FFFFFF&width=400%20400w"
          name="2024 BMW X5"
          price="$65200"
        />
        <Product
          number="4"
          src="https://vehicle-images.dealerinspire.com/d215-110009553/thumbnails/large/WP1BA2AY6RDA50881/d0e046cb1e6b20475ed3167ac9b008cc.jpg"
          name="2024 Porsche Cayenne Coupe"
          price="$84300"
        />
      </div>
    </div>
    <div id="footer">
      <h3>Automobile Cart</h3>
    </div>
  </React.StrictMode>
);
