import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <h1>Haozhe Lu</h1>
    <p>
      My email: <a href="mailto:haozhelu@usc.edu">haozhelu@usc.edu</a>
    </p>
    <div id="main">
      <p id="color">
        Favorite color: <strong>Blue</strong>
      </p>
      <p>
        Favorite Website: <a href="https://www.topgear.com/">Top Gear</a>
      </p>
      <p>Favorite Activity:</p>
      <img
        className="imgs"
        src="https://cdn.britannica.com/75/4375-050-6C798665/Susi-Susanti-women-singles-title-All-England-Championships-1993.jpg"
        alt="Badminton"
      />
      <div id="classes">
        <ul>
          <li>ITP 301</li>
          <li>CSCI 104</li>
          <li>EE109</li>
          <li>MATH407</li>
        </ul>
      </div>
    </div>
  </React.StrictMode>
);
