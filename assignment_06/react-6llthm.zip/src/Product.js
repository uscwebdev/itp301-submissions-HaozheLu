import React from 'react';
export default function Product(props) {
  return (
    <div id={'car' + props.number} className="auto">
      <img className="img" src={props.src} alt={props.name} />
      <strong>{props.name}</strong>
      <strong>{props.price}</strong>
    </div>
  );
}
